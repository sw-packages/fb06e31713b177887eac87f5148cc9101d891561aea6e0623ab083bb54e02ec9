void build(Solution &s)
{
    auto &t = s.addLibrary("Manu343726.tinyrefl", "master");
    t += Git("https://github.com/Manu343726/tinyrefl");
}
